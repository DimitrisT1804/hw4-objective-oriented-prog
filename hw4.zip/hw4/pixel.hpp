/* Header File for Pixel class*/

#ifndef pixel
#define pixel

class Pixel
{
    public:
        int pixel_value;
        unsigned char red;
        unsigned char green;
        unsigned char blue;
        int Y, U, V;
};
#endif