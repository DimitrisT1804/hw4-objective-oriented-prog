/* Source File for Pixel class*/

#include "pixel.hpp"

int pixel_value = -1;    // keep the value of pixel
unsigned char red = ' ';
unsigned char green = ' ';
unsigned char blue = ' ';    
int Y = -1, U = -1, V = -1;     // for YUV type images
