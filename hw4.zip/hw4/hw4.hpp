#include <iostream>
#include <fstream>
#include <vector>
#include <string.h>

#include <math.h>
#include <algorithm>