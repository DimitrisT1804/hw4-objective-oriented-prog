/* Header File for clip class */

#ifndef CLIP_H
#define CLIP_H

int clip(double value);

#endif
